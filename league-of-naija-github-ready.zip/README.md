# League of Naija

Fullstack Nigerian esports community website.

## Structure
- `frontend/` — React UI
- `backend/` — Node.js + Express API