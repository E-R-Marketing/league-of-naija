# League of Naija Frontend

React-based esports community frontend.